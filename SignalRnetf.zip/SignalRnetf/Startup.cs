﻿using Microsoft.AspNet.SignalR;
using Microsoft.Owin;
using Owin;
using System;
using System.Threading.Tasks;
using System.Web.Services.Description;

[assembly: OwinStartup(typeof(SignalRnetf.Startup))]

namespace SignalRnetf
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=316888

            GlobalHost.DependencyResolver.UseStackExchangeRedis("", port, "", "SignalRnetf");
            app.MapSignalR();
        }
    }
}
